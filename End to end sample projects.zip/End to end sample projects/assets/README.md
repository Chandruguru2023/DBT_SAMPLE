# Assets

This folder is to be used for files that should be included in our documentation.