{% macro money(col) -%}
::decimal(16,4)
{%- endmacro %}


