
SELECT area_of_circle(1.0) AS area