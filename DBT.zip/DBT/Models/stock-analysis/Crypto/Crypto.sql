with CRYPTO as 
(
select *,'OMR' as SYMBOL from {{ source('Crypto', 'CRYPTO_OMR_DAILY_STG') }}
union all
select *,'KYD' as SYMBOL from {{ source('Crypto', 'CRYPTO_KYD_DAILY_STG') }}
union all
select *,'KWD' as SYMBOL from {{ source('Crypto', 'CRYPTO_KWD_DAILY_STG') }}
union all
select *,'JOD' as SYMBOL from {{ source('Crypto', 'CRYPTO_JOD_DAILY_STG') }}
union all
select *,'INR' as SYMBOL from {{ source('Crypto', 'CRYPTO_INR_DAILY_STG') }}
union all
select *,'GIP' as SYMBOL from {{ source('Crypto', 'CRYPTO_GIP_DAILY_STG') }}
union all
select *,'GBP' as SYMBOL from {{ source('Crypto', 'CRYPTO_GBP_DAILY_STG') }} 
union all
select *,'EUR' as SYMBOL from {{ source('Crypto', 'CRYPTO_EUR_DAILY_STG') }} 
union all
select *,'CHF' as SYMBOL from {{ source('Crypto', 'CRYPTO_CHF_DAILY_STG') }} 
union all
select *,'BHD' as SYMBOL from {{ source('Crypto', 'CRYPTO_BHD_DAILY_STG') }}
)
select _1_A_OPEN_BHD_ as _1_A_OPEN, _1_B_OPEN_USD_ as _1_B_OPEN, _2_A_HIGH_BHD_ as  _2_A_HIGH,
 _2_B_HIGH_USD_ as _2_B_HIGH, _3_A_LOW_BHD_ as _3_A_LOW, _3_B_LOW_USD_ as _3_B_LOW,
_4_A_CLOSE_BHD_ as _4_A_CLOSE, _4_B_CLOSE_USD_ as _4_B_CLOSE,
_5_VOLUME , _6_MARKET_CAP_USD_ as _6_MARKET_CAP, DATE_TIME, SYMBOL from CRYPTO