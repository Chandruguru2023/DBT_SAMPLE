with Master_cal as
(
    select * from {{ ref('Master_calendar')}}
),
CRYPTO as
(
    select * from {{ ref('CRYPTO')}}
)
select * from Master_cal
inner join CRYPTO on date=(DATE_TIME::date)