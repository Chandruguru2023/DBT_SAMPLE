with Master_cal as
(
    select * from {{ ref('Master_calendar')}}
),
FOREX as
(
    select * from {{ ref('FOREX')}}
)
select * from Master_cal
inner join FOREX on date= (DATE_TIME::date)