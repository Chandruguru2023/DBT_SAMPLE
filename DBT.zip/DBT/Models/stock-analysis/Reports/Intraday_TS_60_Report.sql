with Master_cal as
(
    select * from {{ ref('Master_calendar')}}
),
TS_1s as
(
    select * from {{ ref('TS_60')}}
)
select * from Master_cal
inner join TS_1s on date=(date_time::date)