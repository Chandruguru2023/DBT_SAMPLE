    with Master_cal as
(
    select * from {{ ref('Master_calendar')}}
),
COMMODITIES as
(
    select DATE	as market_Date,VALUE,NAME,INTERVAL, UNIT from {{ ref('COMMODITIES')}}
)
select * from Master_cal
inner join COMMODITIES on date=(market_Date::date)