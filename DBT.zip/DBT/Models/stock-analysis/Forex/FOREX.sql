with FOREX as
(
select *,'OMR' as SYMBOL from {{ source('Forex', 'FOREX_FX_OMR_DAILY_STG') }}
union all
select *,'KYD' as SYMBOL from {{ source('Forex', 'FOREX_FX_KYD_DAILY_STG') }}
union all
select *,'KWD' as SYMBOL from {{ source('Forex', 'FOREX_FX_KWD_DAILY_STG') }}
union all
select *,'JOD' as SYMBOL from {{ source('Forex', 'FOREX_FX_JOD_DAILY_STG') }}
union all
select *,'INR' as SYMBOL from {{ source('Forex', 'FOREX_FX_INR_DAILY_STG') }}
union all
select *,'GIP' as SYMBOL from {{ source('Forex', 'FOREX_FX_GIP_DAILY_STG') }}
union all
select *,'GBP' as SYMBOL from {{ source('Forex', 'FOREX_FX_GBP_DAILY_STG') }} 
union all
select *,'EUR' as SYMBOL from {{ source('Forex', 'FOREX_FX_EUR_DAILY_STG') }} 
union all
select *,'CHF' as SYMBOL from {{ source('Forex', 'FOREX_FX_CHF_DAILY_STG') }} 
union all
select *,'BHD' as SYMBOL from {{ source('Forex', 'FOREX_FX_BHD_DAILY_STG') }}
)
select OPEN,HIGH,LOW,CLOSE,DATE_TIME,SYMBOL from FOREX