with COMMODITIES as 
(
  Select * from  {{ ref('CRUDE_OIL_PRICES_BRENT')}}
  union all 
  Select * from  {{ ref('NATURAL_GAS_SPOT_PRICE')}}
  union all
  Select * from  {{ ref('CRUDE_OIL_PRICES_WTI')}}
  union all
  select * from  {{ ref('ALUMINUM')}}
  union all
  Select * from  {{ ref('COFFEE')}}
  union all
  Select * from  {{ ref('SUGAR')}}
  union all
  Select * from  {{ ref('COPPER')}}
  union all
  Select * from  {{ ref('CORN')}}
  union all
  Select * from  {{ ref('COTTON')}}
  union all
  Select * from  {{ ref('WHEAT')}}
)

select * from COMMODITIES