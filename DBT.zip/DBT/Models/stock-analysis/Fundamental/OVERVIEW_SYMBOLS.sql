select * from {{ source('Fundamental', 'OVERVIEW_SYMBOLS_STG') }}
