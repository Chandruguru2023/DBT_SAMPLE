select fiscal_Date_Ending, Symbols, reported_Date,
reported_EPS::Float as reported_EPS,
estimated_EPS::Float as estimated_EPS,
surprise::Float as surprise,
surprise_Percentage::Float as surprise_Percentage
from {{ source('Fundamental', 'EARNINGS_STG') }}
