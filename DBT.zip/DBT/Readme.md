

## Model Floader

In the Models folder contains different yml and sql files which help you to get data from the soure and to do some transformation

## dbt_project.yml
 
In this file will define schemas, type of o/p(table, view), description and few more paramets:
The below code is to build table in the custom schems

## It should follow the folder structure
models:
  stock:
    # Applies to all files under models/example/
    stock-analysis:
      Commodities: 
        +schema: STOCK_TARGET  ## this code is to create a all objects from Commodities folder into the Stock_Target schema
        +materialized: table   ## this code is define the objects like view, table.
      Crypto:
        +schema: STOCK_TARGET
        +materialized: table
      Forex:
        +schema: STOCK_TARGET
        +materialized: table
      Fundamental:
        +schema: STOCK_TARGET
        +materialized: table
      Intraday:
        +schema: STOCK_TARGET
        +materialized: table
      Reports:
        +schema: STOCK_REPORT
        +materialized: view
        